 

## Main features:
- authorization | registration and login which works with backend
- posting items for sell only for authorized users
- changing the UI in case of anonymous or authorized user
- deleting only own items for authorized users
- dynamic movement through routes during the selection of a product category

## Stack: 
TypeScript, Node.js, Express.js, MongoDb + Mongoose, Multer, React, Axios, Redux-Toolkit, Redux-Persist, React-Router, Material UI, Styled-Components

# To run this app:
1. Clone this repository

### Market Place with backend and frontend
![market-place](https://user-images.githubusercontent.com/99384076/225580567-3363b857-edab-4e57-b8c8-5b3723d512a3.gif)

## Main features:
- authorization | registration and login which works with backend
- posting items for sell only for authorized users
- changing the UI in case of anonymous or authorized user
- deleting only own items for authorized users
- dynamic movement through routes during the selection of a product category

## Stack: 
TypeScript, Node.js, Express.js, MongoDb + Mongoose, Multer, React, Axios, Redux-Toolkit, Redux-Persist, React-Router, Material UI, Styled-Components

# To run this app:
1. Clone this repository

## For backend:
If you have installed MongoDb:

# Backend dependencies
npm install express mongoose multer

 
# Development dependencies
# Backend dependencies
 Install all necessary dependencies:
npm install express mongoose multer


# Development dependencies
2.1. Install all necessary dependencies:

npm install --save-dev nodemon dotenv @types/express @types/mongoose @types/multer @types/react @types/react-dom @types/react-router-dom @types/redux-persist @types/styled-components

 

2.2. Update database: ```npm run seed```

2.3. Start server: ```npm run dev```

## For frontend: 
# Frontend dependencies
3.1. Install all necessary dependencies:
npm install react react-dom react-router-dom axios @reduxjs/toolkit react-redux redux-persist @mui/material @emotion/react @emotion/styled styled-components
 

3.2. Start the app: ```npm start```
